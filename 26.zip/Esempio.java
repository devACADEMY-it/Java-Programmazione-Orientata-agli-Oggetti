public class Esempio {

	public static void main(String[] args) {
		
    }
}
