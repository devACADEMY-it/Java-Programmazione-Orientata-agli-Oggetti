public class Abito extends Prodotto{
	
	public Abito(String nome, byte taglia) {
		super(nome);
		this.taglia=taglia;
	}

	private byte taglia;

	public byte getTaglia() {
		return taglia;
	}

	public void setTaglia(byte taglia) {
		this.taglia = taglia;
	}
	
}
