public class AbitoGala extends Abito{

	private String tipologiaCerimonia;
	
	public AbitoGala(String nome, byte taglia) {
		super(nome, taglia);
	}

	public String getTipologiaCerimonia() {
		return tipologiaCerimonia;
	}

	public void setTipologiaCerimonia(String tipologiaCerimonia) {
		this.tipologiaCerimonia = tipologiaCerimonia;
	}
	
	

}
