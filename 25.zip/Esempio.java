public class Esempio {

	public static void main(String[] args) {
		Abito a=new Abito("Vestito XY", (byte) 50);
		
		Abito b=new Abito("Vestito ABC", (byte) 48);
		b.setPrezzo(110);
		
		System.out.println(a.getNome()+" ha taglia "
						   +a.getTaglia()
						   +" e costa "+a.getPrezzo()+" euro");
		
		System.out.println(b.getNome()+" ha taglia "
				   +b.getTaglia()
				   +" e costa "+b.getPrezzo()+" euro");
    }
}
