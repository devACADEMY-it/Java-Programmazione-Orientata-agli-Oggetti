
public class Libro extends Prodotto{

	private String autore;
	private String titolo;
	
	public Libro(String titolo, String autore) {
		this.titolo=titolo;
		this.autore=autore;
	}
	
	@Override
	public void eseguiSpedizione() {
		System.out.println("Il Libro viene spedito a domicilio");
	}
	
	@Override
	public String toString() {
		return titolo+" di "+autore;
	}
	
	

}
