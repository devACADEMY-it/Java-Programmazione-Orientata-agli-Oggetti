
public class Terreno extends Prodotto{

	@Override
	public void eseguiSpedizione() {
		System.out.println("Un terreno non può essere spedito");
	}

}
