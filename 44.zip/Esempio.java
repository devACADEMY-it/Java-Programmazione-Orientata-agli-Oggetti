
public class Esempio {

	public static void main(String[] args) {
		Libro l=new Libro("Giardinaggio", "Livio Verdi");
		System.out.println(l);
		l.eseguiSpedizione();
		Terreno t=new Terreno();
		t.eseguiSpedizione();
	}

}
