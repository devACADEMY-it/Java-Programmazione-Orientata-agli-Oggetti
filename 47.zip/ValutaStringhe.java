
public class ValutaStringhe {

	public static boolean tuttaMaiuscola(String input) {
		return input.equals(input.toUpperCase());
	}
	
	public static boolean tuttaMinuscola(String input) {
		return input.equals(input.toLowerCase());
	}
}
