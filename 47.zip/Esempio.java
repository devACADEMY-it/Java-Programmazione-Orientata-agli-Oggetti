
public class Esempio {

	public static void main(String[] args) {
		/*System.out.println(ValutaStringhe.tuttaMaiuscola("ciao"));
		System.out.println(ValutaStringhe.tuttaMaiuscola("ciAo"));
		System.out.println(ValutaStringhe.tuttaMaiuscola("CIAO"));
		System.out.println(ValutaStringhe.tuttaMinuscola("ciao"));
		System.out.println(ValutaStringhe.tuttaMinuscola("ciAo"));
		System.out.println(ValutaStringhe.tuttaMinuscola("CIAO"));*/
		
		String daValutare="CIAo";
		if (ValutaStringhe.tuttaMaiuscola(daValutare))
			System.out.println(daValutare+" tutta maiuscola");
		else
			System.out.println(daValutare+" non tutta maiuscola");
		
	}

}
