class Prodotto{
	String nome;
	float prezzo;
}

public class PrimaClasse {

	public static void main(String[] args) {
		Prodotto prodotto1=new Prodotto();
		prodotto1.nome="Dentifricio XYZ";
		prodotto1.prezzo=3;
		
		System.out.println(prodotto1.nome+
				" costa "+
				prodotto1.prezzo+
				" euro");
		
		Prodotto prodotto2=new Prodotto();
		prodotto2.nome="Penna ABC";
		prodotto2.prezzo=2;
		
		System.out.println(prodotto2.nome+
				" costa "+
				prodotto2.prezzo+
				" euro");
		
		Prodotto altro_prodotto=prodotto1;
		System.out.println(altro_prodotto.nome+
				" costa "+
				altro_prodotto.prezzo+
				" euro");
	}

}
