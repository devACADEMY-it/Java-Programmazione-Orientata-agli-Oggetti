
public class TooShortNameException extends RuntimeException{
	public TooShortNameException(String msg)
	{
		super(msg);
	}
}
