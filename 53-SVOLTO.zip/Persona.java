
public class Persona {
	private String nome;
	private int eta;
	
	public Persona(String nome) {
		if (nome.length()<2)
			throw new TooShortNameException("Nome deve essere almeno di due caratteri");
		this.nome=nome;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		if (nome.length()<2)
			throw new TooShortNameException("Nome troppo corto");
		this.nome = nome;
	}
	public int getEta() {
		return eta;
	}
	public void setEta(int eta) {
		if (eta<0)
			throw new WrongAgeException("Valore non valido");
		this.eta = eta;
	}
	
	@Override
	public String toString() {
		return nome+" ha "+eta+" anni";
	}
}
