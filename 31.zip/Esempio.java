public class Esempio {

	public static void main(String[] args) {
		Computer c1=new Computer("PC Star", 800);
		c1.setRAM(8);
		c1.setDisco(512);
		c1.setProcessore("Processore AB");
		
		Computer c2=new Computer("PC Star2", 1100);
		c2.setRAM(12);
		c2.setDisco(512);
		c2.setProcessore("Processore XY");
		
		System.out.println(c1);
		System.out.println(c2);
    }
}
