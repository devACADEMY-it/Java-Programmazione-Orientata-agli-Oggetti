public class Computer extends Prodotto {

	private String processore;
	private int RAM;
	private int disco;
	
	public Computer(String nome, float prezzo) {
		super(nome, prezzo);
	}

	public String getProcessore() {
		return processore;
	}

	public void setProcessore(String processore) {
		this.processore = processore;
	}

	public int getRAM() {
		return RAM;
	}

	public void setRAM(int rAM) {
		RAM = rAM;
	}

	public int getDisco() {
		return disco;
	}

	public void setDisco(int disco) {
		this.disco = disco;
	}

	@Override
	public String toString() {
		return getNome()+" ha processore "+this.processore
				+", RAM "+this.RAM+" GB e costa "+getPrezzo()+" euro";
	}
	
	

}
