public class Esempio {

	public static void main(String[] args) {
		String frase="Il meglio deve ancora venire!";
		
		System.out.println(frase.indexOf('e',12));
		System.out.println(frase.indexOf("deve"));
		
		boolean esclamativo=frase.endsWith("!");
		if (esclamativo)
			System.out.println("Termina con !");
		else
			System.out.println("Non termina con !");
		
		esclamativo=frase.startsWith("!");
		if (esclamativo)
			System.out.println("Inizia con !");
		else
			System.out.println("Non inizia con !");
    }
}
