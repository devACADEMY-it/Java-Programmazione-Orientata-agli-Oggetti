class Prodotto{
	String nome;
	float prezzo;
}

public class PrimaClasse {

	public static void main(String[] args) {
		Prodotto prodotto1=new Prodotto();
		prodotto1.nome="Dentifricio XYZ";
		prodotto1.prezzo=1;
		
		System.out.println(prodotto1.nome+
				" costa "+
				prodotto1.prezzo+
				" euro");
		
		
	}

}
