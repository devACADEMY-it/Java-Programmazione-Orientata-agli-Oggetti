package esercizio.ecommerce.persone;

public class Autore extends Persona{
	
	public Autore(String nome, String cognome, String biografia) {
		super(nome, cognome);
		this.biografia=biografia;
	}

	private String biografia;
	
	@Override
	public String toString() {
		return getCognome()+" "+getNome()+"\n"+biografia;
	}
}
