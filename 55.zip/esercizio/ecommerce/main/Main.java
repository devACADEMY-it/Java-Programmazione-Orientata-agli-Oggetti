package esercizio.ecommerce.main;
import esercizio.ecommerce.persone.Destinatario;
import esercizio.ecommerce.persone.Autore;

public class Main {

	public static void main(String[] args) {
		Destinatario dest=new Destinatario("Gianni", "Rossi");
		dest.setIndirizzo("via Roma 50, Milano");
		
		
		Autore aut=new Autore("Enea", "Verdi", "Esperto di botanica");
		
		System.out.println(dest);
		System.out.println();
		
		System.out.println(aut);
	}

}
