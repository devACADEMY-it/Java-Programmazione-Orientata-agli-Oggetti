public class Esempio {

	public static void main(String[] args) {
                Abito a=new Abito("Vestito ABC", 150, (byte) 50);
		Abito b=new Abito("Vestito XY", 85, (byte) 48);
		System.out.println(a.getNome()+" ha taglia "+a.getTaglia());
		System.out.println(b.getNome()+" ha taglia "+b.getTaglia());
    }
}
