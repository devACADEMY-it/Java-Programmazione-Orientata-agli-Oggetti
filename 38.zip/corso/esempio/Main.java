package corso.esempio;

public class Main {

	public static void main(String[] args) {
		GestoreLista gestore=new GestoreLista();
		gestore.aggiungiNomi("Mario", "Alessia");
		System.out.println("Sono gestiti "+gestore.getLunghezzaLista()+" elementi");
		
		gestore.aggiungiNomi("Andrea", "Irene", "Silvia");
		System.out.println("Sono gestiti "+gestore.getLunghezzaLista()+" elementi");
		
		gestore.aggiungiNomi("Pietro");
		System.out.println("Sono gestiti "+gestore.getLunghezzaLista()+" elementi");
	}

}
