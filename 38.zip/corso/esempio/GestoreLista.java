package corso.esempio;
import java.util.ArrayList;

public class GestoreLista {
	private ArrayList<String> nomi=new ArrayList<String>();
	
	public void aggiungiNomi(String... nuovi) {
		for(String daAggiungere: nuovi) {
			System.out.println("> Aggiungo: "+daAggiungere);
			nomi.add(daAggiungere);
		}
	}
	
	public int getLunghezzaLista() {
		return nomi.size();
	}
}
