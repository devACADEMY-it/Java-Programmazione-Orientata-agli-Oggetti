class Prodotto{
	String nome;
	float prezzo;
	
	float piuIva() {
		return prezzo*1.22f;
	}
	
}

public class PrimaClasse {

	public static void main(String[] args) {
		Prodotto prodotto1=new Prodotto();
		prodotto1.nome="Scarpe JK";
		prodotto1.prezzo=50;
		System.out.println(prodotto1.nome+
				" costa "+
				prodotto1.piuIva()+
				" euro IVA inclusa");
	}

}
