public class Esempio {

	public static void main(String[] args) {
		String frase="Il meglio deve ancora venire!";
		
		//if (frase.indexOf("peggio")>=0)
		if (frase.contains("meglio"))
		      System.out.println("Elemento presente");
		else
			  System.out.println("Elemento non presente");
		
		System.out.println("A".compareToIgnoreCase("z"));
		
    }
}
