public class Esempio {

	public static void main(String[] args) {
      String frase="Un anno fa i miei amici hanno "
      		       + "conosciuto mio fratello Ermanno";
      
      String stringa_da_cercare="anno";
      int conteggio=0;
      int indice=0;
      
      while(indice!=-1) {
    	  indice=frase.indexOf(stringa_da_cercare, indice);
    	  
    	  if (indice>=0) {
    		  conteggio++;
    		  indice+=stringa_da_cercare.length();
    	  }
      }
      System.out.println(conteggio);
      
		
    }
}
