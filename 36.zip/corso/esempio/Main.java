package corso.esempio;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		ArrayList<String> nomi=new ArrayList<String>();
		nomi.add("Mario");
		nomi.add("Luca"); // posizione 1
		nomi.add("Alessia");
		nomi.add("Roberta");
		nomi.remove(1);
		System.out.println("Nome in posizione 2: "+nomi.get(2));
		System.out.println("La lista contiene "+nomi.size()+" nomi");
	}

}
