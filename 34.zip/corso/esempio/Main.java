package corso.esempio;
import corso.esempio.componenti.Saluto;

public class Main {

	public static void main(String[] args) {
		Saluto saluto=new Saluto();
		System.out.println(saluto.getSaluto());
	}

}
