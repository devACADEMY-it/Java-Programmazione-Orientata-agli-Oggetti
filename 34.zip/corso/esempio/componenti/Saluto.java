package corso.esempio.componenti;

public class Saluto {
	private String saluto="Buongiorno a tutti!";
	
	public String getSaluto() {
		return saluto;
	}
}
