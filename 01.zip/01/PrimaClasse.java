class Prodotto{
	String nome;
	float prezzo;
}

public class PrimaClasse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
