
public interface Spedibile {
	void eseguiSpedizione();
}
