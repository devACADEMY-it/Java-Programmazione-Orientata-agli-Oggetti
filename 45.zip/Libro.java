
public class Libro extends Prodotto implements Spedibile{

	@Override
	public void eseguiSpedizione() {
		System.out.println("Il Libro viene spedito a domicilio");
	}

}
