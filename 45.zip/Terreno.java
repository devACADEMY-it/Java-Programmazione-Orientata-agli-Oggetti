
public class Terreno extends Prodotto{

}
