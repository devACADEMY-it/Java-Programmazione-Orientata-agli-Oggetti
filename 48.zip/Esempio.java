
public class Esempio {

	public static void main(String[] args) {
		try {
				float risultato=4/0;
				System.out.println("Risultato: "+risultato);
				}
		catch(Exception e) {
			System.out.println("Si è verificato un errore");
		}
	    System.out.println("Ultima riga");
	}

}
