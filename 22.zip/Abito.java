public class Abito extends Prodotto{

}
