
public class Esempio {

	public static void main(String[] args) {
		int area=Geometria.areaRettangolo(50, 3);
		System.out.println(area);
	}

}
