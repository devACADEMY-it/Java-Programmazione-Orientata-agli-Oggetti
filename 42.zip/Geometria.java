
public class Geometria {

	public static int areaRettangolo(int base, int altezza) {
		return base*altezza;
	}
}
