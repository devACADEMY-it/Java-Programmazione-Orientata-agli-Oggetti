package esercizio.ecommerce.gestione;
import esercizio.ecommerce.persone.Autore;

public class Libro {
	private Autore autore;
	private String titolo;
	
	public Libro(Autore autore, String titolo) {
		this.autore=autore;
		this.titolo=titolo;
	}
	
	public Autore getAutore() {
		return autore;
	}
	public void setAutore(Autore autore) {
		this.autore = autore;
	}
	public String getTitolo() {
		return titolo;
	}
	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}
	
	@Override
	public String toString() {
		return titolo+": "+autore.getCognome()+" "+autore.getNome();
	}
}
