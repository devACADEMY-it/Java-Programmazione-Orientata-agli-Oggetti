package esercizio.ecommerce.gestione;
import java.util.ArrayList;

import esercizio.ecommerce.persone.Destinatario;

public class Ordine {
	private ArrayList<Libro> libri=new ArrayList<Libro>();
	private Destinatario destinatario;
	private boolean ordineChiuso;
	
	public Ordine(Destinatario destinatario) {
		this.destinatario=destinatario;
	}
	
	public void aggiungiLibri(Libro... libri) {
		for(Libro l: libri)
			this.libri.add(l);
	}
	
	public void chiudiOrdine() {
		ordineChiuso=true;
	}
}
