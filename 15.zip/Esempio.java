public class Esempio {

	public static void main(String[] args) {
		String frase="Il meglio deve ancora venire!";
		
		int lunghezza=frase.length();
		System.out.println("La stringa ha lunghezza: "+lunghezza);
		System.out.println("La stringa ha lunghezza: "+frase.length());
		
		System.out.println(frase.toLowerCase());
		System.out.println(frase.toUpperCase());
		System.out.println(frase);
	}

}
