package corso.esempio;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		ArrayList<String> nomi=new ArrayList<String>();
		nomi.add("Mario");
		nomi.add("Luca");
		nomi.add("Alessia");
		nomi.add("Roberta");
		
		for (String singoloNome: nomi)
			System.out.println("> "+singoloNome);
		/*
		for (int i=0; i<nomi.size(); i++)
			System.out.println("> "+nomi.get(i));*/
	}

}
