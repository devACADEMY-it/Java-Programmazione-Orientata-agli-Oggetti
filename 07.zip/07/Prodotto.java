public class Prodotto {
	private String nome;
	private float prezzo;
	
	Prodotto(String nome, float prezzo){
		this.nome=nome;
		this.prezzo=prezzo;
	}
	
	void stampa(){
		System.out.println(nome+" costa "+prezzo+" euro");
	}
}
