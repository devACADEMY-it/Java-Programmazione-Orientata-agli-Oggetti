public class Esempio {

	public static void main(String[] args) {
		Prodotto p=new Prodotto("Quaderno AB", 3);
		Prodotto p1=new Prodotto("Tablet XY", 95);
		
		System.out.println(p);
		System.out.println(p1);
    }
}
