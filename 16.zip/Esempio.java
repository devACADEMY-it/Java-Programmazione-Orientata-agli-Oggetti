public class Esempio {

	public static void main(String[] args) {
		String frase="Il meglio deve ancora venire!";
		
		//String sottostringa=frase.substring(6);
		String sottostringa=frase.substring(6, 12);
		
		String sostituzione=frase.replace("e", "X");
        System.out.println(sottostringa);
        System.out.println(sostituzione);
        System.out.println(frase);
}

}
