package esercizio.ecommerce.eccezioni;

public class OrdineChiusoException extends RuntimeException {
	public OrdineChiusoException(String msg) {
		super(msg);
	}
}
