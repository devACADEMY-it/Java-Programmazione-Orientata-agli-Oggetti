package esercizio.ecommerce.persone;

public class Destinatario extends Persona{
	
	public Destinatario(String nome, String cognome) {
		super(nome, cognome);
	}

	private String indirizzo;

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	
	@Override
	public String toString() {
		return getCognome()+" "+getNome()+"\n"+indirizzo;
	}
	
}
