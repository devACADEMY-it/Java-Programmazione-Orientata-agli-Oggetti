package esercizio.ecommerce.gestione;
import java.util.ArrayList;

import esercizio.ecommerce.eccezioni.OrdineChiusoException;
import esercizio.ecommerce.persone.Destinatario;

public class Ordine {
	private ArrayList<Libro> libri=new ArrayList<Libro>();
	private Destinatario destinatario;
	private boolean ordineChiuso;
	
	public Ordine(Destinatario destinatario) {
		this.destinatario=destinatario;
	}
	
	public void aggiungiLibri(Libro... libri) {
		if (ordineChiuso)
			throw new OrdineChiusoException("Ordine chiuso");
		for(Libro l: libri)
			this.libri.add(l);
	}
	
	public void chiudiOrdine() {
		ordineChiuso=true;
	}
	
	public void stampaFattura() {
		if (!ordineChiuso)
			throw new OrdineChiusoException("Ordine da chiudere");
		System.out.println("FATTURA");
		System.out.println(destinatario);
		System.out.println();
		float totale=0f;
		for (Libro l: libri) {
			System.out.println(l);
			totale+=l.getPrezzo();
		}
		System.out.println("Totale: "+totale+" euro");
	}
	
	
	
	
}
