package esercizio.ecommerce.main;
import esercizio.ecommerce.persone.Destinatario;
import esercizio.ecommerce.eccezioni.OrdineChiusoException;
import esercizio.ecommerce.gestione.Libro;
import esercizio.ecommerce.gestione.Ordine;
import esercizio.ecommerce.persone.Autore;

public class Main {

	public static void main(String[] args) {
		Destinatario dest=new Destinatario("Gianni", "Rossi");
		dest.setIndirizzo("via Roma 50, Milano");
		
		Autore aut=new Autore("Enea", "Verdi", "Esperto di botanica");
		
		Libro l1=new Libro(aut, "Giardinaggio");
		l1.setPrezzo(20);
		Libro l2=new Libro(aut, "Fiori e piante");
		l2.setPrezzo(33);
		Libro l3=new Libro(aut, "Le rose");
		l3.setPrezzo(18);
		
		try {
		Ordine ordine=new Ordine(dest);
		ordine.aggiungiLibri(l1, l2);
		ordine.aggiungiLibri(l3);
		ordine.chiudiOrdine();
		ordine.stampaFattura();
		}
		catch (OrdineChiusoException oce) {
			System.out.println("Chiudere prima l'ordine, prego");
		}
	}

}
