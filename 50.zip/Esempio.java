
public class Esempio {

	public static void main(String[] args) {
		try {
			int risultato=4/2;
			System.out.println("Risultato: "+risultato);
		}
		catch(ArithmeticException a) {
			System.out.println("Eccezione aritmetica");
		}
		finally {
			System.out.println("Eseguito sempre");
		}
		System.out.println("Ultima riga");
	}
	
}
