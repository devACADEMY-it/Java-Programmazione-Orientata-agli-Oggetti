class Libro{
	String titolo;
	String autore;
	int pagine;
}

public class Esercizio {

	public static void main(String[] args) {
		Libro libro1=new Libro();
		libro1.titolo="Manuale di calcio";
		libro1.autore="Ezio Bianchi";
		libro1.pagine=450;
		
		System.out.println("\""+libro1.titolo+"\" scritto da "+
		libro1.autore+" composto da "+libro1.pagine+" pagine");
	}

}
