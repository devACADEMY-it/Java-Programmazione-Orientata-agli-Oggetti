
public class Esempio {

	public static void main(String[] args) {
		int massimo = Math.max(25, 12);
		System.out.println(massimo);
		System.out.println(Math.random()*20);
	}

}
