
public class Esempio {

	public static void main(String[] args) {
		try {
			Persona p=new Persona("Giacomo");
			p.setEta(-5);
			System.out.println(p);
		}
		catch(WrongAgeException e) {
			System.out.println("Valore non valido");
		}
		System.out.println("Fine programma");
	}
	
}
