
public class WrongAgeException extends RuntimeException{
	public WrongAgeException(String msg) {
		super(msg);
	}
}
