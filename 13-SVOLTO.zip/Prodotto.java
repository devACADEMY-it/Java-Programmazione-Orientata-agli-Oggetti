public class Prodotto {
	private String nome;
	private float prezzo;
	private float cambio;
	
	Prodotto(String nome, float prezzo){
		this.nome=nome;
		this.prezzo=prezzo;
	}
	
	void setCambio(float cambio) {
		this.cambio=cambio;
	}
	
	float getPrezzo() {
		return this.prezzo;
	}
	
	float getPrezzoDollari() {
		float risultato=this.prezzo*this.cambio;
		return risultato;
	}
	
	void stampa(){
		System.out.println(nome+" costa "+prezzo+" euro");
	}
	
	void stampaDollari(){
		System.out.println(nome+" costa "+this.getPrezzoDollari()+" dollari");
	}
	
}






