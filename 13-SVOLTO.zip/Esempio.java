public class Esempio {

	public static void main(String[] args) {
		Prodotto prodotto=new Prodotto("Scarpe XY", 60);
		prodotto.stampa();
		prodotto.setCambio(0.8f);
		prodotto.stampaDollari();
		prodotto.setCambio(0.9f);
		prodotto.stampaDollari();
	}

}
