
public class Valore {
	private int valore;
	
	Valore(int iniziale){
		this.valore=iniziale;
	}
	
	Valore(){
		this.valore=0;
	}
	
	void incremento() {
		valore++;
	}
	
	void incremento(int numero) {
		valore+=numero;
	}
	
	int getValore() {
		return valore;
	}
}
