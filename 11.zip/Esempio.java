public class Esempio {

	public static void main(String[] args) {
       Valore v=new Valore();
       
       v.incremento();
       v.incremento();
       v.incremento(3);
       v.incremento();
       System.out.println(v.getValore());
		
    }
}
