public class Abito extends Prodotto{
	
	public Abito(String nome, float prezzo, byte taglia) {
		super(nome, prezzo);
		this.taglia=taglia;
	}

	private byte taglia;

	public byte getTaglia() {
		return taglia;
	}

	public void setTaglia(byte taglia) {
		this.taglia = taglia;
	}
	
	@Override
	public String toString() {
		return super.toString()+
			   " e ha taglia "+this.taglia;
	}
	
}
