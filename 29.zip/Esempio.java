public class Esempio {

	public static void main(String[] args) {
		Abito a=new Abito("Vestito A", 100, (byte) 50);
		System.out.println(a);
    }
}
