public class Esempio {

	public static void main(String[] args) {
		Prodotto prodotto1=new Prodotto("Quaderno ABC", 1.5f);
		prodotto1.stampa();
		float prezzoEstratto=prodotto1.getPrezzo();
		System.out.println("Prezzo scontato = "+prezzoEstratto*0.9);
	}

}
