public class Esempio {

	public static void main(String[] args) {
		String frase="Il meglio deve ancora venire!";
		String altra_frase=new String("Il meglio deve ancora venire!");
		System.out.println(frase);
		System.out.println(altra_frase);
		
		if (frase.equals(altra_frase))
			System.out.println("Uguali");
		else
			System.out.println("Diverse");
    }
}
