
public class Esempio {

	public static void main(String[] args) {
		try {
			int numeri[]= {12, 18, 22, 32, 44};
			int divisore=2;
			for (int i=0; i<=numeri.length; i++) {
				int risultato=numeri[i]/divisore;
				System.out.println("Risultato: "+risultato);
			}
		}
		catch (ArithmeticException e) {
			System.out.println("Errore aritmetico");
		}
		/*catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Errore nella posizione dell'array");
		}*/
		catch (Exception e) {
			System.out.println("Errore generico");
		}
		System.out.println("Ultima riga");
	}

}
