package corso.esempio.componenti;

public class Saluto {
	protected String saluto="Buongiorno a tutti!";
	
	public String getSaluto() {
		return saluto;
	}
}
