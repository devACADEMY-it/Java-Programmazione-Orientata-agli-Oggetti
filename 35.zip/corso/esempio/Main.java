package corso.esempio;

public class Main {

	public static void main(String[] args) {
		SalutoAvanzato saluto=new SalutoAvanzato();
		System.out.println(saluto.getSaluto());
	}

}
