package corso.esempio;
import corso.esempio.componenti.Saluto;

public class SalutoAvanzato extends Saluto{
	
	public SalutoAvanzato() {
		this.saluto+=" Da SalutoAvanzato";
	}
	
}
