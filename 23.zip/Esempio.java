public class Esempio {

	public static void main(String[] args) {
		Prodotto p=new Prodotto();
		Abito a=new Abito();
		
		a.setNome("Vestito ABC");
		a.setPrezzo(150);
		a.setTaglia((byte) 50);
		
		System.out.println("Abito "+a.getNome()+
				            " costa "+a.getPrezzo()+
				            " euro e ha taglia "+a.getTaglia());
		
		
    }
}
