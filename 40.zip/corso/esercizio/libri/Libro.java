package corso.esercizio.libri;

public class Libro extends Prodotto {
		private String titolo;
		private String autore;
		
		public Libro(String titolo, String autore, float prezzo) {
			this.titolo=titolo;
			this.autore=autore;
			this.prezzo=prezzo;
		}
		
		@Override
		public String toString() {
			return "\""+titolo+"\" di "+autore+" costa "+prezzo+" euro"; 
		}
		
}
