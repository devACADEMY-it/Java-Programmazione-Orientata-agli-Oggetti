package corso.esercizio;
import corso.esercizio.libri.Libro;

public class Esercizio {

	public static void main(String[] args) {
		Libro l= new Libro("Giardinaggio","Luigi Verdi", 12.5f);
		System.out.println(l);
	}

}
